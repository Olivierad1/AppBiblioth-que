package javax.persistence;

public @interface Column {

}
