package javax.persistence;

public @interface OneToOne {

}
