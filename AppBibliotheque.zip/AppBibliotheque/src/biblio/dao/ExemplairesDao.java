package biblio.dao;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import biblio.domain.EnumStatusExemplaire;
import biblio.domain.Exemplaire;


public class ExemplairesDao {

	Connection cnx1 = null;
	
public ExemplairesDao(Connection cnx1) {
		this.cnx1=cnx1;
	}

public ExemplairesDao() {
	
}

public Exemplaire findByKey(int idExemplaire) throws SQLException
{
	Statement stmt1 = cnx1.createStatement();
	ResultSet rs2 = stmt1.executeQuery(
			"select idexemplaire,status,dateachat,isbn "+
			" FROM exemplaire where idexemplaire = " + idExemplaire);			
	Exemplaire ex = null;
	
	boolean next = rs2.next();
	

	if( next ) {
		int idexemplaire = rs2.getInt("idexemplaire"); 
		String status = rs2.getString("status");
		String dateachat=rs2.getDate("dateachat").toString(); 
		String isbn = rs2.getString("isbn");
		EnumStatusExemplaire enumStatus = EnumStatusExemplaire.valueOf(status);
		
		ex = new Exemplaire( idexemplaire, dateachat, enumStatus, isbn); 
	}
	else {
		ex = null;
	}
	
	
	return ex;
		
}
	
public ArrayList<Exemplaire> findAll() throws SQLException
{
	Statement stmt1 = cnx1.createStatement();
	ArrayList <Exemplaire> listeExemplaire= new ArrayList<Exemplaire>();
	ResultSet rs3 = stmt1.executeQuery("select * FROM exemplaire");			
	while( rs3.next()){
		
		int idexemplaire = rs3.getInt(1); 
		String dateachat=rs3.getDate(2).toString(); 
		String isbn = rs3.getString(4);
		String status = rs3.getString(3);
		EnumStatusExemplaire enstex = EnumStatusExemplaire.valueOf(status);
		
	
		Exemplaire ex = new Exemplaire(idexemplaire,dateachat,enstex,isbn);
		listeExemplaire.add(ex);
		
	}
	
	return listeExemplaire;
}
	
}