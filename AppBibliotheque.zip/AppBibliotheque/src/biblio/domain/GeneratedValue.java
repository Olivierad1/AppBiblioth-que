package biblio.domain;

public @interface GeneratedValue {

}
