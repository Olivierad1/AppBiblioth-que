package biblio.domain;

public enum EnumStatusExemplaire 
{
   PRETE,DISPONIBLE,SUPPRIME;
	
}
