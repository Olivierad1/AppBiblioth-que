package biblio.domain;

public class Auteur extends Personne 
{
 
   private String test;
      
   public Auteur() 
   {
   
	   
   }
}
