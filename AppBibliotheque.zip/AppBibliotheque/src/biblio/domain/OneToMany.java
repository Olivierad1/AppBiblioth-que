package biblio.domain;

public @interface OneToMany {

}
