package biblio.domain;

public interface GenerationType {

	

}
