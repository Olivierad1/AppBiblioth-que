package biblio.domain;

public class Editeur 
{
   private String nomEditeur;
   private String ville;
   
   public Editeur() 
   {
    
   }
}
