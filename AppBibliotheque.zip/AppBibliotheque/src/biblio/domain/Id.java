package biblio.domain;

public @interface Id {

}
