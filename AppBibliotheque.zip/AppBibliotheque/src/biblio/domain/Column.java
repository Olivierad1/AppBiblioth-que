package biblio.domain;

public @interface Column {

}
