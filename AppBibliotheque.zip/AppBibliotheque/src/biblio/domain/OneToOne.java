package biblio.domain;

public @interface OneToOne {

}
