package biblio.domain;

public @interface Entity {

}
