package biblio.domain;

public enum EnumCategorieEmploye 
{
   BIBLIOTHECAIRE,RESPONSABLE,GESTIONNAIRE;

}
