package biblio.control;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import biblio.dao.EmpruntArchiveDao;
import biblio.dao.EmpruntEnCoursDao;
import biblio.dao.ExemplairesDao;
import biblio.dao.PingJdbc;
import biblio.domain.EmpruntArchive;
import biblio.domain.Exemplaire;

public class RetourCtl {

	public static void main(String[] args) throws NumberFormatException, SQLException, FileNotFoundException, IOException {
		
		System.out.println("\n-------------Test 2.4 :Retour d'un emprunt en cours par un Employ� ou un Adh�rent-----------------------");
		
		int z=0;
		
		while(z==0) {
			
			z=JOptionPane.showConfirmDialog(null, "Vous voulez retourner l'exemplaire d'un livre ? ", "Retour de l'exemplaire d'un livre", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			
			if (z==1 ) continue;
		
		new ExemplairesDao(PingJdbc.getConnectionByProperties());
		String c = JOptionPane.showInputDialog(null, "Saississez l'ID de l'exemplaire retourn� ( de 1 � 8 ): ","Retour d'un exemplaire de livre emprunt�", JOptionPane.INFORMATION_MESSAGE);
		EmpruntEnCoursDao eecd4 = new EmpruntEnCoursDao(PingJdbc.getConnectionByProperties());
		eecd4.removeEmpruntEnCours(Integer.parseInt(c));

		ExemplairesDao eecd5 = new ExemplairesDao(PingJdbc.getConnectionByProperties());
		System.out.println("\nEtats des exemplaires disponibles : \n");
		for(Exemplaire w : eecd5.findAll()) {
			if ( w.getStatus().toString().equalsIgnoreCase("DISPONIBLE")) System.out.println("Exemplaire id : "+w+"\n");
		}
		
		z=JOptionPane.showConfirmDialog(null, "Vous voulez retourner l'exemplaire d'un livre ? ", "Retour de l'exemplaire d'un livre", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		
		}
		
		JOptionPane.showMessageDialog(null, "Merci d'avoir retourn� l'exemplaire de votre livre !", "Session Termin�", JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static String retour(String c) throws NumberFormatException, SQLException, FileNotFoundException, IOException {
		if (! c.isBlank()) {
		new ExemplairesDao(PingJdbc.getConnectionByProperties());
		EmpruntEnCoursDao eecd4 = new EmpruntEnCoursDao(PingJdbc.getConnectionByProperties());
		eecd4.removeEmpruntEnCours(Integer.parseInt(c));

		ExemplairesDao eecd5 = new ExemplairesDao(PingJdbc.getConnectionByProperties());
		String result = "\nEtats des exemplaires disponibles : \n\n";
		for(Exemplaire w : eecd5.findAll()) {
			if ( w.getStatus().toString().equalsIgnoreCase("DISPONIBLE")) result = result + "Exemplaire id : "+w+"\n";
		}
		
		EmpruntArchiveDao eecd9 = new EmpruntArchiveDao(PingJdbc.getConnectionByProperties());
		String result2 = "\nEtats des exemplaires archiv�s de l'utilisateur qui retourne l'exemplaire d'un livre : \n\n";
		for(EmpruntArchive x : eecd9.findAll()) {
			result2 = result2 + "Exemplaires archiv�s : "+x+"\n";
		}
		result = result+result2;
		return result;
		}
		return "Saississez l'ID de l'Exemplaire dans son champs !";
	}

}
